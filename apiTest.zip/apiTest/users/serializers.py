from rest_framework import serializers
from users.models import SpUser


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = SpUser
        fields = ['userid', 'usercount', 'username', 'usersex', 'userage', 'userqq', 'userwechat', 'usertel', 'useraddress', 'roleid', 'userbz']
