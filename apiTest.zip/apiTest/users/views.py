# from django.shortcuts import render

# Create your views here.
from users.models import SpUser
from rest_framework import viewsets
from users.serializers import UserSerializer


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = SpUser.objects.all().order_by('userid')
    serializer_class = UserSerializer

